<?php

//var_dump(delete_option('_iron_music_music_player_options'));


if ( is_admin()) {
	include 'rational-option-page/class.rational-option-page.php';
	$ironFeatures_pages = new RationalOptionPages();
	$ironFeatures_pages_options = array(
	    array(
	        'page_title'    => esc_html__('SoundRise Music','soundrise-music'),
	        'menu_title'    => esc_html__('SoundRise Music','soundrise-music'),
	        'capability'    => 'manage_options',
	        'menu_slug'     => 'soundrise-music',
	        'icon_url'      => IRON_MUSIC_DIR_URL . '/images/ironlogo.svg',
	        'position'      => '9999999999999999999999999999',
			'subpages'		=> array(
				array(
					'page_title'	=> esc_html__('Events','soundrise-music'),
					'menu_title' 	=> esc_html__('Events','soundrise-music'),
					'capability'    => 'manage_options',
					'menu_slug'     => 'iron_music_event',
					'sections'      => array(
						array(
							'id'    => 'iron_events',
							'title' => esc_html__('General Settings','soundrise-music'),
							'fields'=> array(
								// text input
								array(
									'id'    => 'events_slug_name',
									'title' => esc_html__('Events slug name','soundrise-music'),
									'type'  => 'text',
									'description' => esc_html__('eg: http://www.domain.com/SLUG/event-title','soundrise-music'),
									'value' => 'event'
								),
								array(
									'id' => 'events_per_page',
									'type' => 'text',
									'title' => esc_html__('How many events per page ?', 'soundrise-music'),
									'description' => esc_html__('This setting apply on your event page template.', 'soundrise-music'),
									'value' => '10'
								),
							)
						),
						array(
							'id'    => 'iron_events_items',
							'title' => esc_html__('Look and Feel','soundrise-music'),
							'fields'=> array(
								array(
									'id' => 'events_item_typography',
									'type' => 'typography',
									'title' => esc_html__('Typography', 'soundrise-music'),
									'description' => esc_html__('Choose a font, font size and color', 'soundrise-music'),
									'value' => array(
										'font' => 'Karla',
										'font-readable' => 'Karla',
										'weight' => '400',
										'size' => '18px',
										'color' => 'rgb(43, 43, 43)',
									)
								),
								array(
									'id'    => 'events_items_letterspacing',
									'type'  => 'text',
									'title' => esc_html__('Letter Spacing', 'soundrise-music'),
									'description' => esc_html__('enter value with px (eg: 2px)','soundrise-music'),
									'value' => '0px'
								),
								array(
									'id' => 'events_item_bg_color',
									'type' => 'text',
									'class' => 'color',
									'title' => esc_html__('Item Background Color', 'soundrise-music'),
									'value' => 'rgb(255, 255, 255)'
								),
								array(
									'id' => 'events_item_hover_bg_color',
									'type' => 'text',
									'class' => 'color',
									'title' => esc_html__('Item Hover Background Color', 'soundrise-music'),
									'value' => 'rgb(43, 43, 43)'
								),
								array(
									'id' => 'events_item_hover_text_color',
									'type' => 'text',
									'class' => 'color',
									'title' => esc_html__('Item Hover Text Color', 'soundrise-music'),
									'value' => 'rgb(255, 255, 255)'
								),
							),
						),
						array(
							'id'    => 'iron_events_countdown',
							'title' => esc_html__('Countdown','soundrise-music'),
							'fields'=> array(
								array(
									'id' => 'events_show_countdown_rollover',
									'type' => 'checkbox',
									'title' => esc_html__('Show countdown on rollover', 'soundrise-music'),
									'description' => esc_html__('When option is checked, an animated countdown will be shown when user rollover your event. This global setting may be overridden in each of your individual events.', 'soundrise-music'),
								),
								array(
									'id' => 'events_countdown_typography',
									'type' => 'typography',
									'title' => esc_html__('Typography', 'soundrise-music'),
									'description' => esc_html__('Choose a font, font size and color', 'soundrise-music'),
									'value' => array(
										'font' => 'Karla',
										'font-readable' => 'Karla',
										'weight' => '600',
										'size' => '21px',
										'color' => 'rgb(255, 255, 255)',
									)
								),
								array(
									'id'    => 'events_countdown_letterspacing',
									'type'  => 'text',
									'title' => esc_html__('Letter Spacing', 'soundrise-music'),
									'description' => esc_html__('enter value with px','soundrise-music'),
									'value' => '0px'
								),
								array(
									'id' => 'events_countdown_bg_color',
									'type' => 'text',
									'class' => 'color',
									'title' => esc_html__('Background Color', 'soundrise-music'),
									'value' => 'rgb(143, 34, 75)'
								),
								array(
									'id' => 'events_outline_colors',
									'type' => 'text',
									'class' => 'color',
									'title' => esc_html__('Outline Color', 'soundrise-music'),
									'description' => esc_html__('For separators', 'soundrise-music'),
									'value' => 'rgb(43, 43, 43)'
								),
								array(
									'id'    => 'events_items_padding',
									'type'  => 'text',
									'title' => esc_html__('Padding between items', 'soundrise-music'),
									'description' => esc_html__('enter value with px. eg: 5px','soundrise-music'),
									'value' => '20px'
								),
							),
						),
						array(
							'id'    => 'iron_events_filter',
							'title' => esc_html__('Artist Dropdown','soundrise-music'),
							'fields'=> array(
								array(
									'id' => 'events_filter',
									'type' => 'checkbox',
									'title' => esc_html__('Show Artist Dropdown', 'soundrise-music'),
									'description' => esc_html__('Show an artist dropdown selector above your list of events. If you have multiple artists, this can be usefull to filter your events by artists. This option only apply in pages that use the "Event Posts" template.','soundrise-music'),
									'switch' => true,
								),
								array(
									'id'    => 'events_filter_label',
									'type'  => 'text',
									'title' => esc_html__('Text Label', 'soundrise-music'),
									'description' => esc_html__('eg: Select an artist','soundrise-music'),
									'value' => ''
								),
								array(
									'id' => 'events_filter_typography',
									'type' => 'typography',
									'title' => esc_html__('Label Typography', 'soundrise-music'),
									'description' => esc_html__('Choose a font, font size and color', 'soundrise-music'),
									'value' => array(
										'font' => 'Karla',
										'font-readable' => 'Karla',
										'weight' => '400',
										'size' => '15px',
										'color' => 'rgb(43, 43, 43)',
									)
								),
								array(
									'id'    => 'events_filter_letterspacing',
									'type'  => 'text',
									'title' => esc_html__('Label Letter Spacing', 'soundrise-music'),
									'description' => esc_html__('enter value with px (eg: 2px)','soundrise-music'),
									'value' => '0px'
								),
								array(
									'id' => 'events_filter_bg_color',
									'type' => 'text',
									'class' => 'color',
									'title' => esc_html__('Background Color', 'soundrise-music'),
									'value' => 'rgb(240, 240, 240)'
								),
								array(
									'id' => 'events_filter_outline_color',
									'type' => 'text',
									'class' => 'color',
									'title' => esc_html__('Event filter Outline Color', 'soundrise-music'),
									'description' => esc_html__('For dropdown outlines and arrow color', 'soundrise-music'),
									'value' => 'rgb(0, 0, 0)'
								),
							)
						),

					),
				),
				array(
					'page_title'	=> esc_html__('Music Player','soundrise-music'),
					'menu_title' 	=> esc_html__('Music Player','soundrise-music'),
					'capability'    => 'manage_options',
					'menu_slug'     => 'iron_music_music_player',
					'sections'		=> array(
						array(
							'id' 	=> 'iron_music_player',
							'title'	=> esc_html__('Music Player Color Setting', 'soundrise-music'),
							'fields'=> array(
								array(
									'id' => 'music_player_song_title',
									'type' => 'typography',
									'title' => esc_html__('Music Player Song Title', 'soundrise-music'),
									'description' => esc_html__('Choose a font, font size and color', 'soundrise-music'),
									'value' => array(
										'font' => 'Karla',
										'font-readable' => 'Karla',
										'weight' => '700',
										'size' => '16px',
										'color' => 'rgb(43, 43, 43)',
									)
								),
								array(
									'id' => 'music_player_album_title',
									'type' => 'typography',
									'title' => esc_html__('Music Player Album Title', 'soundrise-music'),
									'description' => esc_html__('Choose a font, font size and color', 'soundrise-music'),
									'value' => array(
										'font' => 'Karla',
										'font-readable' => 'Karla',
										'weight' => '400',
										'size' => '14px',
										'color' => 'rgb(43, 43, 43)',
									)
								),
								array(
									'id' => 'music_player_playlist',
									'type' => 'typography',
									'title' => esc_html__('Playlist', 'soundrise-music'),
									'description' => esc_html__('Choose a font, font size and color', 'soundrise-music'),
									'value' => array(
										'font' => 'Karla',
										'font-readable' => 'Karla',
										'weight' => '400',
										'size' => '16px',
										'color' => 'rgb(43, 43, 43)',
									)
								),
								array(
									'id' => 'music_player_playlist_active_text_color',
									'type' => 'text',
									'title' => esc_html__('Playlist active text color', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(77, 77, 79)'
								),
								array(
									'id' => 'music_player_playlist_hover_color',
									'type' => 'text',
									'title' => esc_html__('Playlist hover', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(215, 215, 215)'
								),
								array(
									'id' => 'music_player_icon_color',
									'type' => 'text',
									'title' => esc_html__('Player control color', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(127, 127, 127)'
								),
								array(
									'id' => 'music_player_timeline_color',
									'type' => 'text',
									'title' => esc_html__('Timeline background', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(31, 31, 31)'
								),
								array(
									'id' => 'music_player_progress_color',
									'type' => 'text',
									'title' => esc_html__('Progress bar', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(13, 237, 180)'
								),
							)
						),
						array(
							'id' 	=> 'iron_music_continuous_player',
							'title'	=> esc_html__('Continuous Music Player Color Setting', 'soundrise-music'),
							'fields'=> array(
								array(
									'id' => 'continuous_music_player_label_color',
									'type' => 'text',
									'title' => esc_html__('Music Player Label Color', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(0, 0, 0)'
								),
								array(
									'id' => 'continuous_music_player_background',
									'type' => 'text',
									'title' => esc_html__('Footer music player background', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(0, 0, 0)'
								),
								array(
									'id' => 'continuous_music_player_control_color',
									'type' => 'text',
									'title' => esc_html__('Player Control Color', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(255, 255, 255)'
								),
								array(
									'id' => 'continuous_music_player_timeline_background',
									'type' => 'text',
									'title' => esc_html__('Timeline background', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(255, 255, 255)'
								),
								array(
									'id' => 'continuous_music_player_progress_bar',
									'type' => 'text',
									'title' => esc_html__('Progress bar', 'soundrise-music'),
									'class' => 'color',
									'value' => 'rgb(150, 150, 150)'
								),


							)
						)
					)
				),
				array(
					'page_title'	=> esc_html__('Discography','soundrise-music'),
					'menu_title' 	=> esc_html__('Discography','soundrise-music'),
					'capability'    => 'manage_options',
					'menu_slug'     => 'iron_music_discography',
					'sections'      => array(
						array(
							'id'    => 'iron_discography',
							'title' => esc_html__('Discography Features','soundrise-music'),
							'fields'=> array(
								// text input
								array(
									'id'    => 'discography_slug_name',
									'title' => esc_html__('Discography Slug Name','soundrise-music'),
									'type'  => 'text',
									'description' => esc_html__('eg: http://www.domain.com/SLUG-NAME/album-title','soundrise-music'),
									'value' => 'albums'
								),
							)
						),
					),
				),

				array(
					'page_title'	=> 'Import / Export',
					'menu_title' 	=> 'Import / Export',
					'capability'    => 'manage_options',
					'menu_slug'     => 'iron_music_import_export',
					'sections'      => array(
						array(
							'id'    => 'iron_import_export',
							'title' => esc_html__('Import / Export','soundrise-music'),
							'fields' => array(

								array(
									'id' => 'external_css',
									'type' => 'checkbox',
									'title' => esc_html__('Move Dynamic/Custom CSS Into External Stylesheet?', 'soundrise-music'),
									'description' => esc_html__('This gives you the option move all the dynamic css that lives in the head by default into its own file for aesthetic & caching purposes', 'soundrise-music'),
									'value' => 0
								),
								array(
									'id' => 'import_html',
									'title' => esc_html__('Data to import', 'soundrise-music'),
									'type' => 'html',
									'data' => '<textarea class="import"></textarea><br><button class="btn import">Import data</button>'
								),
								array(
									'id' => 'export_html',
									'title' => esc_html__('Data to export', 'soundrise-music'),
									'type' => 'htmlExport',
									'export_options' => array(
										'_iron_music_event_options',
								        '_iron_music_music_player_options',
								        '_iron_music_discography_options'
									)
								),
							)
						),
					),
				),
			),
	    ),
	);


	$ironFeatures_pages->pages( $ironFeatures_pages_options );

}
