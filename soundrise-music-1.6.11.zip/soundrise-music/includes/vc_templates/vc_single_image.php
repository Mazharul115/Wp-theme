<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $iron_soundrise_atts
 * @var $iron_soundrise_title
 * @var $iron_soundrise_source
 * @var $iron_soundrise_image
 * @var $iron_soundrise_custom_src
 * @var $iron_soundrise_onclick
 * @var $iron_soundrise_img_size
 * @var $iron_soundrise_external_img_size
 * @var $iron_soundrise_caption
 * @var $iron_soundrise_img_link_large
 * @var $iron_soundrise_link
 * @var $iron_soundrise_img_link_target
 * @var $iron_soundrise_alignment
 * @var $iron_soundrise_el_class
 * @var $iron_soundrise_css_animation
 * @var $iron_soundrise_style
 * @var $iron_soundrise_external_style
 * @var $iron_soundrise_border_color
 * @var $iron_soundrise_css
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Single_image
 */

$iron_soundrise_atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $iron_soundrise_atts , EXTR_PREFIX_ALL, 'iron_soundrise');

$iron_soundrise_default_src = vc_asset_url( 'vc/no_image.png' );

// backward compatibility. since 4.6
if ( empty( $iron_soundrise_onclick ) && isset( $iron_soundrise_img_link_large ) && 'yes' === $iron_soundrise_img_link_large ) {
	$iron_soundrise_onclick = 'img_link_large';
} elseif ( empty( $iron_soundrise_atts['onclick'] ) && ( ! isset( $iron_soundrise_atts['img_link_large'] ) || 'yes' !== $iron_soundrise_atts['img_link_large'] ) ) {
	$iron_soundrise_onclick = 'custom_link';
}

if ( 'external_link' === $iron_soundrise_source ) {
	$iron_soundrise_style = $iron_soundrise_external_style;
	$iron_soundrise_border_color = $iron_soundrise_external_border_color;
}

$iron_soundrise_border_color = ( '' !== $iron_soundrise_border_color ) ? ' vc_box_border_' . $iron_soundrise_border_color : '';

$iron_soundrise_img = false;

switch ( $iron_soundrise_source ) {
	case 'media_library':
	case 'featured_image':

		if ( 'featured_image' === $iron_soundrise_source ) {
			$post_id = get_the_ID();
			if ( $post_id && has_post_thumbnail( $post_id ) ) {
				$iron_soundrise_img_id = get_post_thumbnail_id( $post_id );
			} else {
				$iron_soundrise_img_id = 0;
			}
		} else {
			$iron_soundrise_img_id = preg_replace( '/[^\d]/', '', $iron_soundrise_image );
		}

		// set rectangular
		if ( preg_match( '/_circle_2$/', $iron_soundrise_style ) ) {
			$iron_soundrise_style = preg_replace( '/_circle_2$/', '_circle', $iron_soundrise_style );
			$iron_soundrise_img_size = $this->getImageSquareSize( $iron_soundrise_img_id, $iron_soundrise_img_size );
		}

		if ( ! $iron_soundrise_img_size ) {
			$iron_soundrise_img_size = 'medium';
		}

		$iron_soundrise_img = wpb_getImageBySize( array(
			'attach_id' => $iron_soundrise_img_id,
			'thumb_size' => $iron_soundrise_img_size,
			'class' => 'vc_single_image-img',
		) );

		// don't show placeholder in public version if post doesn't have featured image
		if ( 'featured_image' === $iron_soundrise_source ) {
			if ( ! $iron_soundrise_img && 'page' === vc_manager()->mode() ) {
				return;
			}
		}

		break;

	case 'external_link':
		$dimensions = vcExtractDimensions( $iron_soundrise_external_img_size );
		$hwstring = $dimensions ? image_hwstring( $dimensions[0], $dimensions[1] ) : '';

		$iron_soundrise_custom_src = $iron_soundrise_custom_src ? esc_attr( $iron_soundrise_custom_src ) : $iron_soundrise_default_src;

		$iron_soundrise_img = array(
			'thumbnail' => '<img class="vc_single_image-img" ' . $hwstring . ' src="' . $iron_soundrise_custom_src . '" />',
		);
		break;

	default:
		$iron_soundrise_img = false;
}

if ( ! $iron_soundrise_img ) {
	$iron_soundrise_img['thumbnail'] = '<img class="vc_img-placeholder vc_single_image-img" src="' . $iron_soundrise_default_src . '" />';
}

$iron_soundrise_el_class = $this->getExtraClass( $iron_soundrise_el_class );

// backward compatibility
if ( vc_has_class( 'prettyphoto', $iron_soundrise_el_class ) ) {
	$iron_soundrise_onclick = 'link_image';
}

// backward compatibility. will be removed in 4.7+
if ( ! empty( $iron_soundrise_atts['img_link'] ) ) {
	$iron_soundrise_link = $iron_soundrise_atts['img_link'];
	if ( ! preg_match( '/^(https?\:\/\/|\/\/)/', $iron_soundrise_link ) ) {
		$iron_soundrise_link = 'http://' . $iron_soundrise_link;
	}
}

// backward compatibility
if ( in_array( $iron_soundrise_link, array( 'none', 'link_no' ) ) ) {
	$iron_soundrise_link = '';
}

$iron_soundrise_a_attrs = array();

switch ( $iron_soundrise_onclick ) {
	case 'img_link_large':

		if ( 'external_link' === $iron_soundrise_source ) {
			$iron_soundrise_link = $iron_soundrise_custom_src;
		} else {
			$iron_soundrise_link = wp_get_attachment_image_src( $iron_soundrise_img_id, 'large' );
			$iron_soundrise_link = $iron_soundrise_link[0];
		}

		break;

	case 'link_image':
		wp_enqueue_script( 'prettyphoto' );
		wp_enqueue_style( 'prettyphoto' );

		$iron_soundrise_a_attrs['class'] = 'prettyphoto';
		$iron_soundrise_a_attrs['rel'] = 'prettyPhoto[rel-' . get_the_ID() . '-' . rand() . ']';

		// backward compatibility
		if ( vc_has_class( 'prettyphoto', $iron_soundrise_el_class ) ) {
			// $link is already defined
		} elseif ( 'external_link' === $iron_soundrise_source ) {
			$iron_soundrise_link = $iron_soundrise_custom_src;
		} else {
			$iron_soundrise_link = wp_get_attachment_image_src( $iron_soundrise_img_id, 'large' );
			$iron_soundrise_link = $iron_soundrise_link[0];
		}

		break;

	case 'custom_link':
		// $link is already defined
		break;

	case 'zoom':
		wp_enqueue_script( 'vc_image_zoom' );

		if ( 'external_link' === $iron_soundrise_source ) {
			$large_img_src = $iron_soundrise_custom_src;
		} else {
			$large_img_src = wp_get_attachment_image_src( $iron_soundrise_img_id, 'large' );
			if ( $large_img_src ) {
				$large_img_src = $large_img_src[0];
			}
		}

		$iron_soundrise_img['thumbnail'] = str_replace( '<img ', '<img data-vc-zoom="' . $large_img_src . '" ', $iron_soundrise_img['thumbnail'] );

		break;
}

// backward compatibility
if ( vc_has_class( 'prettyphoto', $iron_soundrise_el_class ) ) {
	$iron_soundrise_el_class = vc_remove_class( 'prettyphoto', $iron_soundrise_el_class );
}

$iron_soundrise_wrapperClass = 'vc_single_image-wrapper ' . $iron_soundrise_img_fullwidth . ' ' . $iron_soundrise_style . ' ' . $iron_soundrise_border_color;

if ( $iron_soundrise_link ) {
	$iron_soundrise_a_attrs['href'] = $iron_soundrise_link;
	$iron_soundrise_a_attrs['target'] = $iron_soundrise_img_link_target;
	if ( ! empty( $iron_soundrise_a_attrs['class'] ) ) {
		$iron_soundrise_wrapperClass .= ' ' . $iron_soundrise_a_attrs['class'];
		unset( $iron_soundrise_a_attrs['class'] );
	}
	$html = '<a ' . vc_stringify_attributes( $iron_soundrise_a_attrs ) . ' class="' . $iron_soundrise_wrapperClass . '">' . $iron_soundrise_img['thumbnail'] . '</a>';
} else {
	$html = '<div class="' . $iron_soundrise_wrapperClass . '">' . $iron_soundrise_img['thumbnail'] . '</div>';
}



$iron_soundrise_class_to_filter = 'wpb_single_image wpb_content_element vc_align_' . $iron_soundrise_alignment . ' ' . $this->getCSSAnimation( $iron_soundrise_css_animation );
$iron_soundrise_class_to_filter .= vc_shortcode_custom_css_class( $iron_soundrise_css, ' ' ) . $this->getExtraClass( $iron_soundrise_el_class );
$iron_soundrise_css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $iron_soundrise_class_to_filter, $this->settings['base'], $iron_soundrise_atts );

if ( in_array( $iron_soundrise_source, array( 'media_library', 'featured_image' ) ) && 'yes' === $iron_soundrise_add_caption ) {
	$post = get_post( $iron_soundrise_img_id );
	$iron_soundrise_caption = $post->post_excerpt;
} else {
	if ( 'external_link' === $iron_soundrise_source ) {
		$iron_soundrise_add_caption = 'yes';
	}
}

if ( 'yes' === $iron_soundrise_add_caption && '' !== $iron_soundrise_caption ) {
	$html .= '<figcaption class="vc_figure-caption">' . esc_html( $iron_soundrise_caption ) . '</figcaption>';
}

$iron_soundrise_output = '
	<div class="' . esc_attr( trim( $iron_soundrise_css_class ) ) . ' ' . $this->getCSSAnimation( $iron_soundrise_css_animation ) . '">
		' . wpb_widget_title( array( 'title' => $iron_soundrise_title, 'extraclass' => 'wpb_singleimage_heading' ) ) . '
		<figure class="wpb_wrapper vc_figure">
			' . $html . '
		</figure>
	</div>
';

echo $iron_soundrise_output;