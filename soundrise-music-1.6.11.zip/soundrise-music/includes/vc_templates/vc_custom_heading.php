<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
$iron_soundrise_fonts = $this->getAttributes( $atts );
$iron_soundrise_atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $iron_soundrise_atts , EXTR_PREFIX_ALL, 'iron_soundrise');


extract( $this->getStyles( $iron_soundrise_el_class, $iron_soundrise_css, $iron_soundrise_fonts['google_fonts_data'], $iron_soundrise_fonts['font_container_data'], $iron_soundrise_atts ),  EXTR_PREFIX_ALL, 'iron_soundrise' );




$iron_soundrise_settings = get_option( 'wpb_js_google_fonts_subsets' );
if ( is_array( $iron_soundrise_settings ) && ! empty( $iron_soundrise_settings ) ) {
	$iron_soundrise_subsets = '&subset=' . implode( ',', $iron_soundrise_settings );
} else {
	$iron_soundrise_subsets = '';
}

if ( isset( $iron_soundrise_fonts['google_fonts_data']['values']['font_family'] ) ) {
	wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $iron_soundrise_fonts['google_fonts_data']['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $iron_soundrise_fonts['google_fonts_data']['values']['font_family'] . $iron_soundrise_subsets );
}


if($iron_soundrise_atts['fit_bg_text'] == 1) {
	$iron_soundrise_css_class .= " fit_bg_text ";
	if(in_array("text-align: center", $iron_soundrise_styles)){
		$iron_soundrise_css_class .= " fit_bg_center";
	}

}

if ( ! empty( $iron_soundrise_styles ) ) {
	$iron_soundrise_style = 'style="' . esc_attr( implode( ';', $iron_soundrise_styles ) ) . '"';
} else {
	$iron_soundrise_style = '';
}
// CUSTOM FIT TO BG


if ( 'post_title' === $iron_soundrise_source ) {
	$iron_soundrise_text = get_the_title( get_the_ID() );
}

if ( ! empty( $iron_soundrise_link ) ) {
	$iron_soundrise_link = vc_build_link( $iron_soundrise_link );
	$iron_soundrise_text = '<a href="' . esc_attr( $iron_soundrise_link['url'] ) . '"'
		. ( $iron_soundrise_link['target'] ? ' target="' . esc_attr( $iron_soundrise_link['target'] ) . '"' : '' )
		. ( $iron_soundrise_link['title'] ? ' title="' . esc_attr( $iron_soundrise_link['title'] ) . '"' : '' )
		. '>' . $iron_soundrise_text . '</a>';
}

$iron_soundrise_output = '';
if ( apply_filters( 'vc_custom_heading_template_use_wrapper', false ) ) {
	$iron_soundrise_output .= '<div class="' . esc_attr( $iron_soundrise_css_class ) . ' ' . $this->getCSSAnimation( $iron_soundrise_css_animation ) . '" >';
	$iron_soundrise_output .= '<' . $iron_soundrise_fonts['font_container_data']['values']['tag'] . ' ' . $iron_soundrise_style . ' >';
	$iron_soundrise_output .= $iron_soundrise_text;
	$iron_soundrise_output .= '</' . $iron_soundrise_fonts['font_container_data']['values']['tag'] . '>';
	$iron_soundrise_output .= '</div>';
} else {
	$iron_soundrise_output .= '<' . $iron_soundrise_fonts['font_container_data']['values']['tag'] . ' ' . $iron_soundrise_style . ' class="' . esc_attr( $iron_soundrise_css_class ) . ' ' . $this->getCSSAnimation($iron_soundrise_css_animation) . '">';
	$iron_soundrise_output .= $iron_soundrise_text;
	$iron_soundrise_output .= '</' . $iron_soundrise_fonts['font_container_data']['values']['tag'] . '>';
}

echo $iron_soundrise_output;


if(array_key_exists('fit_bg_text', $iron_soundrise_atts) && $iron_soundrise_atts['fit_bg_text'] == "fit_yes") {
	echo '<div class="clear"></div>';
}
