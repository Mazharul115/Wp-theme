<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aximo
 */

 
use aximoTheme\Inc\Classes\Aximo_Main;

$aximoObj = new Aximo_Main();

$aximo        = get_option('aximo');
$show_excerpt = isset($aximo['show_excerpt']) ? $aximo['show_excerpt'] : false;
$grid         = (isset($aximo['blog_grid'])) ? $aximo['blog_grid'] : 'two-column';
switch ($grid) {
	case 'two-column':
		$limit = 17;
		$title = wp_trim_words(get_the_title(), 11, '...');
		break;

	case 'one-column':
		$limit = 30;
		$title = get_the_title();
		break;

	default:
		$limit = 17;
		$title = wp_trim_words(get_the_title(), 11, '...');
		break;
}

?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="single-post-item <?php echo esc_attr($grid)  ?>">
			<div class="post-thumbnail-wrapper">
				<?php
				if (is_sticky()) {
					echo '<span class="sticky-text" >' . esc_html__('Sticky', 'aximo') . '</span>';
				}
				?>
				<?php if (has_post_thumbnail()) : ?>
					<div class="post-thumbnail">

						<?php the_post_thumbnail('full'); ?>
					</div>

				<?php endif; ?>
			</div>


		<div class="post-content">
			<div class="post-meta bottom">

				<?php  $category = get_the_category(); if (!empty($category)):  ?>
							<div class="post-category">
								<?php
									echo '<a href="' . get_category_link($category[0]->term_id) . '"><span class="category-list">' . $category[0]->cat_name . '</span></a>';
								?>
								
							</div>
							
						<?php endif; ?>
	
				<div class="post-date">
					<?php aximo_posted_on() ?>
				</div>
				
			</div>
			
			<?php
			echo '<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">';
			echo esc_html($title);
			echo '</a></h2>';
			?>

			

			<?php 
				echo '<p>' . esc_html($aximoObj->postExcerpt($limit, get_the_excerpt())) . '</p>';
			 ?>

			<div class="post-read-more">
				<a href="<?php echo esc_url(get_permalink()); ?>">
				read more 
				<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M23.3333 8.33325L35 19.9999M35 19.9999L23.3333 31.6666M35 19.9999L5 19.9999" stroke="black" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>

				</a>
			</div>
		</div>
	</div>

</div><!-- #post-<?php the_ID(); ?> -->