<?php

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package aximo
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function aximo_body_classes($classes)
{
    // Adds a class of hfeed to non-singular pages.
    if (!is_singular()) {
        $classes[] = 'hfeed';
    }

    // Adds a class of no-sidebar when there is no sidebar present.
    if (!is_active_sidebar('sidebar-1')) {
        $classes[] = 'no-sidebar';
    }

    return $classes;
}
add_filter('body_class', 'aximo_body_classes');

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function aximo_pingback_header()
{
    if (is_singular() && pings_open()) {
        printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
    }
}
add_action('wp_head', 'aximo_pingback_header');

function aximo_dd($var)
{
    echo '<pre>';
    print_r($var);
    echo '</pre>';
}

/**
 * Detect Homepage
 *
 * @return boolean value
 */
function aximo_detect_homepage()
{
    // If front page is set to display a static page, get the URL of the posts page.
    $homepage_id = get_option('page_on_front');

    // current page id
    $current_page_id = (is_page(get_the_ID())) ? get_the_ID() : '';

    if ($homepage_id == $current_page_id) {
        return true;
    } else {
        return false;
    }
}

/**
 *   Get the site logo for Bufet
 *
 */
function aximo_get_site_logo()
{
    $logo = '';
    $aximo = get_option('aximo');
    $logo_url = '';

    $custom_logo = get_post_meta(get_the_ID(), 'use_custom_logo', true);
    $page_logo = get_post_meta(get_the_ID(), 'select_logo', true);

    if (!empty($custom_logo)) {
        $img_url = wp_get_attachment_image_src($page_logo, 'full');
        $logo_url = esc_url($img_url[0]);
        $logo = '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('title')) . '" class="navbar-brand__regular">';
    } else if (!empty($aximo['logo']['url'])) {
        $logo_url = esc_url($aximo['logo']['url']);
        $logo = '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('title')) . '" class="navbar-brand__regular">';
    } else {
        if (has_custom_logo()) {
            $core_logo_id = get_theme_mod('custom_logo');
            $logo_url = wp_get_attachment_image_src($core_logo_id, 'full');
            $logo = '<img src="' . esc_url($logo_url[0]) . '" alt="' . esc_attr(get_bloginfo('title')) . '" class="navbar-brand__regular">';
        } else {
            $logo = '<h1 class="navbar-brand__regular">' . get_bloginfo('name') . '</h1>';
        }
    }

    return $logo;
}

/**
 * Get the site logo for Bufet
 */
function aximo_get_site_sticky_logo()
{

    $aximo = get_option('aximo');

    $logo = '';
    $logo_url = '';

    $custom_logo = get_post_meta(get_the_ID(), 'use_custom_logo', true);
    $page_sticky_logo = get_post_meta(get_the_ID(), 'select_sticky_logo', true);

    if (!empty($custom_logo) && $page_sticky_logo) {
        $img_url = wp_get_attachment_image_src($page_sticky_logo, 'full');
        $logo_url = esc_url($img_url[0]);
        $logo = '<img src="' . esc_url($logo_url) . ' ?>" alt="' . esc_attr(get_bloginfo('title')) . '" class="navbar-brand__sticky">';
    } else if (!empty($aximo['sticky_logo']['url'])) {
        $logo_url = esc_url($aximo['sticky_logo']['url']);
        $logo = '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('title')) . '" class="navbar-brand__sticky">';
    }
    return $logo;
}

add_action('wp_ajax_cloadmore', 'aximo_comments_loadmore_handler'); // wp_ajax_{action}
add_action('wp_ajax_nopriv_cloadmore', 'aximo_comments_loadmore_handler'); // wp_ajax_nopriv_{action}

function aximo_comments_loadmore_handler()
{

    // maybe it isn't the best way to declare global $post variable, but it is simple and works perfectly!
    global $post;
    $post = get_post($_POST['post_id']);
    setup_postdata($post);

    wp_list_comments(
        array(
            'page' => $_POST['cpage'], // current comment page
            'per_page' => get_option('comments_per_page'),
            'style' => 'ol',
            'short_ping' => true,
        )
    );
    die; // don't forget this thing if you don't want "0" to be displayed
}


/**
 * aximo Is edit mode in elementor
 *
 */
function aximo_is_edit_mode(  ) {
    return isset($_GET['elementor-preview']);
}
/**
 * aximo header Settings
 *
 */
function aximo_header_settings() {
    if (defined('ELEMENTOR_PRO_VERSION') && aximo_is_edit_mode() ) {
        return;
    }else{
        $aximo = get_option( 'aximo' );
        $check_header_post = get_posts( ['post_type' => 'aximo_header'] );
        if ( 0 != count( $check_header_post ) ) {
            printf( '<header class="site-header aximo-elementor-header">' );
            aximo_header_footer_template_query( 'aximo_header' );
            printf( '</header>' );
        } else {
            get_template_part( 'template-parts/headers/header-style-1' );
        }
    }
}

/**
 * aximo Footer Settings
 *
 */
function aximo_footer_settings() {
    if (defined('ELEMENTOR_PRO_VERSION') && aximo_is_edit_mode() ) {
        return;
    }else{
        $check_footer_post = get_posts( ['post_type' => 'aximo_footer'] );
        if ( 0 != count( $check_footer_post ) ) {
            aximo_header_footer_template_query( 'aximo_footer' );
        } else {
            aximo_raw_footer();
        }
    }
}
/**
 * aximo Raw Footer
 *
 */
function aximo_raw_footer()
{
    $aximo = get_option('aximo');
    if (isset($aximo['footer_copyright'])) {
        echo '<div class="aximo-copyright text-center">' . $aximo['footer_copyright'] . '</div>';
    } else {
        echo '<div class="aximo-copyright text-center">' . esc_html__('Copyright 2024, All Rights Reserved', 'aximo') . '</div>';
    }
}
function aximo_header_footer_template_query($post_type, $post_id = '') {
    global $post;
    $current_page_id = isset($post->ID) ? $post->ID : false;
    
    // Query for blog posts
    $args = array(
        'post_type' => $post_type,
        'posts_per_page' => -1,
    );

    if (empty($post_id)) {
        $args['p'] =  $post_id;
    }

    $footer_query = new WP_Query($args);
    
    if ($footer_query->have_posts()) :
        while ($footer_query->have_posts()) :
            $footer_query->the_post();
            
            ob_start();
            the_content();
            $content = ob_get_clean();
            
            $output = '';
            
            if (have_rows('include_rules', get_the_ID())) {
                while (have_rows('include_rules', get_the_ID())) {
                    the_row();
                    $specific_pages = get_sub_field('pages') ? get_sub_field('pages') : [];
                    $entire_website = get_sub_field('include_on');
                    $archive = 'archive' == $entire_website ? is_archive() || is_home() || is_search() : false;

                    if ('all' == $entire_website || in_array($current_page_id, $specific_pages) || $archive || ('404' == $entire_website && is_404())) {
                        $output = $content;
                    }
                }
            }

            if (have_rows('exclude_rules', get_the_ID())) {
                while (have_rows('exclude_rules', get_the_ID())) {
                    the_row();
                    $specific_pages = get_sub_field('pages') ? get_sub_field('pages') : [];
                    $entire_website = get_sub_field('exclude_on');
                    $archive = 'archive' == $entire_website ? is_archive() || is_home() || is_search() : false;

                    if ('all' == $entire_website || in_array($current_page_id, $specific_pages) || $archive || ('404' == $entire_website && is_404())) {
                        $output = '';
                    }
                }
            }

            if ($output) {
                printf('%s', $output);
            }
        endwhile;
    endif;

    wp_reset_postdata();
}

/**
 * aximo get archive post type
 *
 */
function aximo_get_archive_post_type()
{
    $postname = isset(get_queried_object()->name) ? get_queried_object()->name : '';
    return is_archive() ? $postname : '';
}

function aximo_preloader()
{
    $aximo = get_option('aximo');
    $preloader = '
    <div class="aximo-preloader-wrap">
        <div class="aximo-preloader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    ';
    if (isset($aximo['enable_preloader'])) {
        if (true == $aximo['enable_preloader']) {
            printf('%s', $preloader);
        }
    } else {
        printf('%s', $preloader);
    }
}