<?php

// File Security Check
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// theme version
if(! defined('AXIMO_THEME_VERSION') ){
    define('AXIMO_THEME_VERSION', wp_get_theme()->get('Version'));
} 

// Define the DHRUBOK Folder
if( ! defined( 'AXIMO_DIR' ) ) {
	define('AXIMO_DIR', get_template_directory() );
}

// Define the DHRUBOK Partials Folder
if( ! defined( 'AXIMO_PARTIALS_DIR' ) ) {
	define('AXIMO_PARTIALS_DIR', trailingslashit( AXIMO_DIR ) . 'partials' );
}

// Define the Inc Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_ASSETS_DIR' ) ) {
	define('AXIMO_ASSETS_DIR', trailingslashit( AXIMO_DIR ) . 'assets' );
}


// Define the Inc Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_INC_DIR' ) ) {
	define('AXIMO_INC_DIR', trailingslashit( AXIMO_DIR ) . 'inc' );
}

// Define the Inc Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_FRAMEWORK_DIR' ) ) {
	define('AXIMO_FRAMEWORK_DIR', trailingslashit( AXIMO_INC_DIR ) . 'framework' );
}

// Define the Libs Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_LIBS_DIR' ) ) {
	define('AXIMO_LIBS_DIR', trailingslashit( AXIMO_DIR ) . 'libs' );
}

// Define the Shortcodes Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_SHORTCODES_DIR' ) ) {
	define('AXIMO_SHORTCODES_DIR', trailingslashit( AXIMO_INC_DIR ) . 'shortcodes' );
}

// Define the Classes Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_CLASSES_DIR' ) ) {
	define('AXIMO_CLASSES_DIR', trailingslashit( AXIMO_INC_DIR ) . 'classes' );
}

// Define the Widgets Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_WIDGETS_DIR' ) ) {
	define('AXIMO_WIDGETS_DIR', trailingslashit( AXIMO_INC_DIR ) . 'widgets' );
}


// Define the PLUGINS Folder of the DHRUBOK Directory
if( ! defined( 'AXIMO_INC_PLUGINS_DIR' ) ) {
	define('AXIMO_INC_PLUGINS_DIR', trailingslashit( AXIMO_INC_DIR ) . 'plugins' );
}
