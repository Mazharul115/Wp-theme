<?php
/**
 * Client Section
 * 
 * @package The_Schema
 */ ?>
    <section id="client_section" class="client-section">
        <div class="container">
            <?php dynamic_sidebar('the-schema-client'); ?>
        </div>
    </section>
<?php 