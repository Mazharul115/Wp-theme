<?php
/**
 * About Section
 * 
 * @package The_Schema
 */ ?>
    <section id="about_section" class="about-section">
        <div class="container">
            <?php dynamic_sidebar('the-schema-about'); ?>
        </div>
    </section>
<?php 