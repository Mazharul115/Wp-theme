<?php
/**
 * Service Section
 * 
 * @package The_Schema
 */ ?>
    <section id="service_section" class="service-section">
        <div class="container">
            <?php dynamic_sidebar('the-schema-service'); ?>
        </div>
    </section>
<?php 